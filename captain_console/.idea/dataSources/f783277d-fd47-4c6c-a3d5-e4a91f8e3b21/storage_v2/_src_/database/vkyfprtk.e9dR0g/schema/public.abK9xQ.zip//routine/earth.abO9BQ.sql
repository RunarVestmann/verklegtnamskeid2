create function earth() returns double precision
    immutable
    parallel safe
    language sql
as
$$
SELECT '6378168'::float8
$$;

alter function earth() owner to postgres;

